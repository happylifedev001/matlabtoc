% Comprehensive DSP-Based Denoising Filters with 3D Visualization in MATLAB

clc;
clear;
close all;

%% Parameters for signal generation
Fs = 1000;             % Sampling frequency (Hz)
t = 0:1/Fs:1;          % Time vector (1 second)
f_signal = 50;         % Original signal frequency (Hz)

%% Original Clean Signal (Sine Wave)
clean_signal = sin(2*pi*f_signal*t);

%% Adding Noise to the Signal (White Gaussian Noise + Impulse Noise)
% Gaussian noise
gaussian_noise = 0.5 * randn(size(t));  
% Impulse noise (Salt and Pepper)
impulse_noise = (rand(size(t)) > 0.98) - 0.5;   
% Combined noise
noisy_signal = clean_signal + gaussian_noise + impulse_noise;

%% Apply Multiple Denoising Filters

% 1. Wiener Filter
denoised_signal_wiener = wiener2(noisy_signal, [1, 10]);  % Wiener filter

% 2. Median Filter
denoised_signal_median = medfilt1(noisy_signal, 10);  % Median filter

% 3. Low-Pass Filter (Butterworth)
[b, a] = butter(6, 0.1);  % 6th order low-pass filter
denoised_signal_lowpass = filtfilt(b, a, noisy_signal);

% 4. Kalman Filter (Simple Kalman for tracking noise)
% Kalman filter initialization
n = length(t);
Q = 0.01;    % Process variance
R = 0.1;     % Measurement variance
kalman_estimate = zeros(1, n);
kalman_gain = zeros(1, n);
P = 1;       % Estimate error covariance
kalman_estimate(1) = noisy_signal(1);  % Initial estimate

for i = 2:n
    % Prediction
    P = P + Q;
    
    % Kalman Gain
    kalman_gain(i) = P / (P + R);
    
    % Update estimate
    kalman_estimate(i) = kalman_estimate(i-1) + kalman_gain(i) * (noisy_signal(i) - kalman_estimate(i-1));
    
    % Update error covariance
    P = (1 - kalman_gain(i)) * P;
end
denoised_signal_kalman = kalman_estimate;

%% 3D Plots for Original, Noisy, and Denoised Signals

% 1. 3D Plot of Original Signal
figure;
subplot(3,2,1);
plot3(t, clean_signal, zeros(size(t)), 'g', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Clean Signal');
title('3D Plot of Clean Signal');
grid on;
view(3);  % 3D View

% 2. 3D Plot of Noisy Signal
subplot(3,2,2);
plot3(t, noisy_signal, zeros(size(t)), 'r', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Noisy Signal');
title('3D Plot of Noisy Signal');
grid on;
view(3);  % 3D View

% 3. 3D Plot of Wiener Filter Denoised Signal
subplot(3,2,3);
plot3(t, denoised_signal_wiener, zeros(size(t)), 'b', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Denoised Signal (Wiener)');
title('3D Plot of Wiener Denoised Signal');
grid on;
view(3);  % 3D View

% 4. 3D Plot of Median Filter Denoised Signal
subplot(3,2,4);
plot3(t, denoised_signal_median, zeros(size(t)), 'm', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Denoised Signal (Median)');
title('3D Plot of Median Denoised Signal');
grid on;
view(3);  % 3D View

% 5. 3D Plot of Low-Pass Filter Denoised Signal
subplot(3,2,5);
plot3(t, denoised_signal_lowpass, zeros(size(t)), 'c', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Denoised Signal (Low-Pass)');
title('3D Plot of Low-Pass Filter Denoised Signal');
grid on;
view(3);  % 3D View

% 6. 3D Plot of Kalman Filter Denoised Signal
subplot(3,2,6);
plot3(t, denoised_signal_kalman, zeros(size(t)), 'k', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Denoised Signal (Kalman)');
title('3D Plot of Kalman Filter Denoised Signal');
grid on;
view(3);  % 3D View

%% Time-Frequency Analysis Using Spectrogram (3D)

% 1. Spectrogram of Noisy Signal
figure;
subplot(2,2,1);
spectrogram(noisy_signal, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Noisy Signal');
colormap jet;
view(3);  % 3D View

% 2. Spectrogram of Wiener Denoised Signal
subplot(2,2,2);
spectrogram(denoised_signal_wiener, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Wiener Denoised Signal');
colormap jet;
view(3);  % 3D View

% 3. Spectrogram of Median Denoised Signal
subplot(2,2,3);
spectrogram(denoised_signal_median, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Median Denoised Signal');
colormap jet;
view(3);  % 3D View

% 4. Spectrogram of Kalman Denoised Signal
subplot(2,2,4);
spectrogram(denoised_signal_kalman, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Kalman Denoised Signal');
colormap jet;
view(3);  % 3D View

%% Performance Analysis: Signal-to-Noise Ratio (SNR)
snr_noisy = snr(clean_signal, noisy_signal - clean_signal);
snr_wiener = snr(clean_signal, denoised_signal_wiener - clean_signal);
snr_median = snr(clean_signal, denoised_signal_median - clean_signal);
snr_lowpass = snr(clean_signal, denoised_signal_lowpass - clean_signal);
snr_kalman = snr(clean_signal, denoised_signal_kalman - clean_signal);

fprintf('SNR of Noisy Signal: %.2f dB\n', snr_noisy);
fprintf('SNR after Wiener Filter: %.2f dB\n', snr_wiener);
fprintf('SNR after Median Filter: %.2f dB\n', snr_median);
fprintf('SNR after Low-Pass Filter: %.2f dB\n', snr_lowpass);
fprintf('SNR after Kalman Filter: %.2f dB\n', snr_kalman);

%% Comparative 3D Time-Frequency Analysis Using Continuous Wavelet Transform (CWT)
figure;
subplot(2,3,1);
cwt(noisy_signal, 'amor', Fs);
title('CWT of Noisy Signal');

subplot(2,3,2);
cwt(denoised_signal_wiener, 'amor', Fs);
title('CWT of Wiener Denoised Signal');

subplot(2,3,3);
cwt(denoised_signal_median, 'amor', Fs);
title('CWT of Median Denoised Signal');

subplot(2,3,4);
cwt(denoised_signal_lowpass, 'amor', Fs);
title('CWT of Low-Pass Denoised Signal');

subplot(2,3,5);
cwt(denoised_signal_kalman, 'amor', Fs);
title('CWT of Kalman Denoised Signal');
