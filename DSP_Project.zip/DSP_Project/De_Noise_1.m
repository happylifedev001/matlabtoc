% Comprehensive Denoising Code Using Wavelet, EMD, and Adaptive Filtering
clc;
clear;
close all;

%% Parameters for signal generation
Fs = 1000;             % Sampling frequency (Hz)
t = 0:1/Fs:1;          % Time vector (1 second)
f_signal = 50;         % Original signal frequency (Hz)

%% Original Clean Signal (Sine Wave)
clean_signal = sin(2*pi*f_signal*t);

%% Adding Noise (Gaussian + Impulse Noise)
gaussian_noise = 0.5 * randn(size(t));       % Gaussian noise
impulse_noise = (rand(size(t)) > 0.98) - 0.5; % Impulse (salt & pepper) noise
noisy_signal = clean_signal + gaussian_noise + impulse_noise;

%% Wavelet-Based Denoising
if exist('wavedec', 'file') == 2
    wavelet_name = 'db4';  % Daubechies wavelet
    level = 4;  % Level of decomposition
    [coeff, lengths] = wavedec(noisy_signal, level, wavelet_name);

    % Thresholding (Soft Thresholding)
    threshold = wthrmngr('dw1ddenoLVL', 'heursure', coeff, lengths);
    denoised_signal_wavelet = wdencmp('gbl', coeff, lengths, wavelet_name, level, threshold, 's');
else
    disp('Wavelet Toolbox not available. Skipping wavelet denoising.');
    denoised_signal_wavelet = noisy_signal; % Keep noisy signal as a placeholder
end

%% Empirical Mode Decomposition (EMD) Denoising
[imfs, res] = emd(noisy_signal);
denoised_signal_emd = res + sum(imfs(3:end, :), 1); % Keep lower-frequency IMFs

%% Savitzky-Golay Filtering (Smoothing Filter)
poly_order = 3;  % Polynomial order
window_size = 21;  % Window size
denoised_signal_sgolay = sgolayfilt(noisy_signal, poly_order, window_size);

%% Adaptive Filtering (LMS Adaptive Filter)
mu = 0.01;  % Step size (learning rate)
filter_order = 32;  % Filter order
lms_adaptive_filter = dsp.LMSFilter('Length', filter_order, 'StepSize', mu);
[denoised_signal_lms, ~, ~] = lms_adaptive_filter(gaussian_noise', noisy_signal');

%% Ensure Signals Are Column Vectors
noisy_signal = noisy_signal(:);
denoised_signal_wavelet = denoised_signal_wavelet(:);
denoised_signal_emd = denoised_signal_emd(:);
denoised_signal_sgolay = denoised_signal_sgolay(:);
denoised_signal_lms = denoised_signal_lms(:);

%% 3D Plots for Noisy and Denoised Signals
figure;
subplot(3,2,1);
plot3(t, noisy_signal, zeros(size(t)), 'r', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Noisy Signal');
title('3D Plot of Noisy Signal');
grid on;
view(3);  % 3D View

subplot(3,2,2);
plot3(t, denoised_signal_wavelet, zeros(size(t)), 'b', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Wavelet Denoised Signal');
title('3D Plot of Wavelet Denoised Signal');
grid on;
view(3);  % 3D View

subplot(3,2,3);
plot3(t, denoised_signal_emd, zeros(size(t)), 'm', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('EMD Denoised Signal');
title('3D Plot of EMD Denoised Signal');
grid on;
view(3);  % 3D View

subplot(3,2,4);
plot3(t, denoised_signal_sgolay, zeros(size(t)), 'c', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('Savitzky-Golay Denoised Signal');
title('3D Plot of Savitzky-Golay Denoised Signal');
grid on;
view(3);  % 3D View

subplot(3,2,5);
plot3(t, denoised_signal_lms, zeros(size(t)), 'g', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
zlabel('LMS Adaptive Filter Denoised Signal');
title('3D Plot of LMS Denoised Signal');
grid on;
view(3);  % 3D View

%% Spectrograms for Time-Frequency Analysis
figure;
subplot(3,2,1);
spectrogram(noisy_signal, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Noisy Signal');
view(3);  % 3D View

subplot(3,2,2);
spectrogram(denoised_signal_wavelet, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Wavelet Denoised Signal');
view(3);  % 3D View

subplot(3,2,3);
spectrogram(denoised_signal_emd, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of EMD Denoised Signal');
view(3);  % 3D View

subplot(3,2,4);
spectrogram(denoised_signal_sgolay, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of Savitzky-Golay Denoised Signal');
view(3);  % 3D View

subplot(3,2,5);
spectrogram(denoised_signal_lms, 256, 250, 256, Fs, 'yaxis');
title('Spectrogram of LMS Denoised Signal');
view(3);  % 3D View

%% 3D Reassigned Spectrograms
figure;

subplot(3,2,1);
[S, F, T] = spectrogram(noisy_signal, 256, 250, 256, Fs);
surf(T, F, 10*log10(abs(S)), 'EdgeColor', 'none'); % 3D Spectrogram
title('3D Reassigned Spectrogram of Noisy Signal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
zlabel('Magnitude (dB)');
view(30, 60);
axis tight; 
colorbar;

subplot(3,2,2);
[S, F, T] = spectrogram(denoised_signal_wavelet, 256, 250, 256, Fs);
surf(T, F, 10*log10(abs(S)), 'EdgeColor', 'none'); % 3D Spectrogram
title('3D Reassigned Spectrogram of Wavelet Denoised Signal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
zlabel('Magnitude (dB)');
view(30, 60);
axis tight; 
colorbar;

subplot(3,2,3);
[S, F, T] = spectrogram(denoised_signal_emd, 256, 250, 256, Fs);
surf(T, F, 10*log10(abs(S)), 'EdgeColor', 'none'); % 3D Spectrogram
title('3D Reassigned Spectrogram of EMD Denoised Signal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
zlabel('Magnitude (dB)');
view(30, 60);
axis tight; 
colorbar;

subplot(3,2,4);
[S, F, T] = spectrogram(denoised_signal_sgolay, 256, 250, 256, Fs);
surf(T, F, 10*log10(abs(S)), 'EdgeColor', 'none'); % 3D Spectrogram
title('3D Reassigned Spectrogram of Savitzky-Golay Denoised Signal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
zlabel('Magnitude (dB)');
view(30, 60);
axis tight; 
colorbar;

subplot(3,2,5);
[S, F, T] = spectrogram(denoised_signal_lms, 256, 250, 256, Fs);
surf(T, F, 10*log10(abs(S)), 'EdgeColor', 'none'); % 3D Spectrogram
title('3D Reassigned Spectrogram of LMS Denoised Signal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
zlabel('Magnitude (dB)');
view(30, 60);
axis tight; 
colorbar;

%% Time-Frequency Analysis: Continuous Wavelet Transform (CWT)
figure;
subplot(2,2,1);
cwt(noisy_signal, 'amor', Fs); 
title('CWT of Noisy Signal');

subplot(2,2,2);
cwt(denoised_signal_wavelet, 'amor', Fs);
title('CWT of Wavelet Denoised Signal');

subplot(2,2,3);
cwt(denoised_signal_emd, 'amor', Fs);
title('CWT of EMD Denoised Signal');

subplot(2,2,4);
cwt(denoised_signal_sgolay, 'amor', Fs);
title('CWT of Savitzky-Golay Denoised Signal');
