% Room dimensions (meters)
room_length = 10;
room_width = 8;
room_height = 6;

% Source and listener positions
source_position = [2, 3, 1.5]; % x, y, z position of the sound source
listener_position = [7, 6, 1.5]; % initial x, y, z position of the listener

% Sampling parameters
Fs = 44100; % Sampling frequency
duration = 2; % Duration of the audio in seconds
t = 0:1/Fs:duration; % Time vector

% Generate a test audio signal (sine wave with frequency modulation)
f0 = 440; % Base frequency (A4)
audio_signal = sin(2*pi*f0*t) + 0.5*sin(2*pi*(f0+200)*t);

% Sound speed (in meters per second)
c = 343;

% Calculate the direct path signal
distance_direct = norm(listener_position - source_position);
time_delay_direct = distance_direct / c;
direct_signal = [zeros(1, round(time_delay_direct * Fs)), audio_signal / distance_direct];

% Reflections from walls
reflection_points = [
    room_length, listener_position(2), listener_position(3); % Front wall
    0, listener_position(2), listener_position(3);           % Back wall
    listener_position(1), room_width, listener_position(3);   % Right wall
    listener_position(1), 0, listener_position(3);           % Left wall
    listener_position(1), listener_position(2), room_height;  % Ceiling
    listener_position(1), listener_position(2), 0            % Floor
];

% Compute reflection signals for each wall
reflection_signals = cell(6, 1);
for i = 1:6
    reflection_position = reflection_points(i, :);
    distance_reflection = norm(reflection_position - source_position);
    time_delay_reflection = distance_reflection / c;
    reflection_signals{i} = [zeros(1, round(time_delay_reflection * Fs)), audio_signal / distance_reflection];
end

% Ensure all signals are of the same length
signal_lengths = [length(direct_signal), ...
                  length(reflection_signals{1}), ...
                  length(reflection_signals{2}), ...
                  length(reflection_signals{3}), ...
                  length(reflection_signals{4}), ...
                  length(reflection_signals{5}), ...
                  length(reflection_signals{6})];

max_signal_length = max(signal_lengths);

% Pad all signals to the maximum length
direct_signal = [direct_signal, zeros(1, max_signal_length - length(direct_signal))];
for i = 1:6
    reflection_signals{i} = [reflection_signals{i}, zeros(1, max_signal_length - length(reflection_signals{i}))];
end

% Combine direct and reflection signals
combined_signal = direct_signal;
for i = 1:6
    combined_signal = combined_signal + reflection_signals{i};
end

% Plot 3D visualization of sound propagation paths
figure;
hold on;
plot3(source_position(1), source_position(2), source_position(3), 'ro', 'MarkerSize', 10, 'DisplayName', 'Source');
plot3(listener_position(1), listener_position(2), listener_position(3), 'bo', 'MarkerSize', 10, 'DisplayName', 'Listener');
plot3([source_position(1), listener_position(1)], [source_position(2), listener_position(2)], [source_position(3), listener_position(3)], 'k--', 'DisplayName', 'Direct Path');

% Plot reflection paths
walls = {'Front Wall', 'Back Wall', 'Right Wall', 'Left Wall', 'Ceiling', 'Floor'};
for i = 1:6
    reflection_position = reflection_points(i, :);
    plot3([source_position(1), reflection_position(1)], [source_position(2), reflection_position(2)], [source_position(3), reflection_position(3)], 'g--', 'DisplayName', walls{i});
    plot3([reflection_position(1), listener_position(1)], [reflection_position(2), listener_position(2)], [reflection_position(3), listener_position(3)], 'b--', 'DisplayName', walls{i});
end
legend('show');
title('3D Sound Propagation Paths');
xlabel('X (meters)');
ylabel('Y (meters)');
zlabel('Z (meters)');
grid on;
axis equal;

% 3D Spectrogram of the combined signal
figure;
spectrogram(combined_signal, 256, 250, 256, Fs, 'yaxis');
view(3); % 3D view of the spectrogram
title('3D Spectrogram of Combined Signal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
zlabel('Amplitude (dB)');

% Power Spectral Density (PSD) comparison
figure;
subplot(2,1,1);
psd_original = pwelch(audio_signal, [], [], [], Fs);
plot(10*log10(psd_original));
title('Original Signal Power Spectral Density');

subplot(2,1,2);
psd_combined = pwelch(combined_signal, [], [], [], Fs);
plot(10*log10(psd_combined));
title('Combined Signal (With Reflections) Power Spectral Density');
