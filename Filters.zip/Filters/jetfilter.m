function [STFTpos, CIFpos, LGDpos, LGDderiv, f, t] = jetfilters(signal, Fs, window, overlap, fftn, low, high, clip)
    if nargin ~= 8
        error('usage: ([STFT [, CIF [, LGD [, f [, t]]]]] = jetfilter(signal [, Fs [, window [, overlap [, fftn [, low [, high [, clip]]]]]]]) ')
    end

    len = length(signal);
    window = hanning(window); 
    win_size = length(window);
    step = win_size - overlap;
    offset = 0:step:len - win_size - 1;

    WW = window * ones(1, length(offset));
    idx = ((1:win_size)' * ones(1, length(offset))) + (ones(win_size, 1) * offset);
    S = signal(idx + 1) .* WW;
    STFT = fft(S, fftn);
    
    % Extract positive frequency components
    ret_n = fftn / 2;  
    if high > Fs * (ret_n - 1) / fftn
        high = Fs * (ret_n - 1) / fftn;
    end
    lowindex = round(low / Fs * fftn);
    lowindex = max(lowindex, 1);  % Ensure it's at least 1
    highindex = round(high / Fs * fftn);

    STFTpos = STFT(lowindex:highindex, :);
    STFTmag = abs(STFTpos);
    STFTmag = 20 * log10(STFTmag ./ max(max(STFTmag)));  % Convert to dB

    % Frequency and Time vectors
    f = Fs * (lowindex - 1:highindex - 1) / fftn;
    t = (offset + win_size / 2) ./ Fs;

    % Compute channelized instantaneous frequency (CIF)
    C = STFTpos .* conj(STFTpos); 
    argC = mod(angle(C), 2 * pi);
    CIFpos = (Fs / 1) .* argC / (2 * pi);

    % Local group delay (LGD)
    LGDpos = -((fftn / Fs) .* mod(angle(STFTpos .* conj(STFTpos)), -2 * pi)) / (2 * pi);
    LGDderiv = []; % Placeholder as we aren't using it in this visualization

    % Plot 3D Reassigned Spectrogram
    figure('Position', [400, 300, 900, 400]);
    scatter3(1000 * (t(:) - min(t)), CIFpos(:), STFTmag(:), 1, STFTmag(:), 'filled');
    view(0, 90);
    xlabel('Time (ms)', 'FontName', 'times', 'FontSize', 14);
    ylabel('Instantaneous Frequency (Hz)', 'FontName', 'times', 'FontSize', 14);
    zlabel('Magnitude (dB)', 'FontName', 'times', 'FontSize', 14);
    title('3D Colored Reassigned Spectrogram', 'FontSize', 16);
    colormap(jet);
    colorbar; % Display color scale for magnitude

    axis tight;
    grid on;

end
